// the whole overlay lives in here
const OVERLAY_ID = "__gif_overlay_ext";

function createOverlay(url, size, pos) {
  removeOverlay();

  const img = document.createElement("img");
  img.id = OVERLAY_ID;
  img.src = url;
  Object.assign(img.style, {
    position: "fixed",
    width: size + "px",
    height: "auto",
    left: (pos?.x ?? 100) + "px",
    top: (pos?.y ?? 100) + "px",
    zIndex: "2147483647",
    pointerEvents: "auto",
    cursor: "grab",
    userSelect: "none",
    // completely transparent chrome, no border, no shadow, nothing
    background: "transparent",
    border: "none",
    outline: "none",
    boxShadow: "none",
    padding: "0",
    margin: "0",
    borderRadius: "0",
  });

  // drag logic
  let dragging = false;
  let offsetX = 0;
  let offsetY = 0;

  img.addEventListener("mousedown", (e) => {
    dragging = true;
    offsetX = e.clientX - img.offsetLeft;
    offsetY = e.clientY - img.offsetTop;
    img.style.cursor = "grabbing";
    e.preventDefault();
  });

  document.addEventListener("mousemove", (e) => {
    if (!dragging) return;
    img.style.left = (e.clientX - offsetX) + "px";
    img.style.top = (e.clientY - offsetY) + "px";
  });

  document.addEventListener("mouseup", () => {
    if (!dragging) return;
    dragging = false;
    img.style.cursor = "grab";
    // save position so it remembers where you left it
    chrome.storage.local.set({
      gifPos: {
        x: parseInt(img.style.left),
        y: parseInt(img.style.top),
      },
    });
  });

  document.body.appendChild(img);
}

function removeOverlay() {
  const existing = document.getElementById(OVERLAY_ID);
  if (existing) existing.remove();
}

// listen for messages from the popup
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "apply") {
    chrome.storage.local.get(["gifPos"], (data) => {
      createOverlay(msg.url, msg.size, data.gifPos);
    });
  }
  if (msg.action === "remove") {
    removeOverlay();
  }
});

// auto-restore on page load if there's a saved gif
chrome.storage.local.get(["gifUrl", "gifSize", "gifPos"], (data) => {
  if (data.gifUrl) {
    createOverlay(data.gifUrl, data.gifSize || 150, data.gifPos);
  }
});
