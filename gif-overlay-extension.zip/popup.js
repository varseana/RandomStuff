// load saved values into the popup fields
chrome.storage.local.get(["gifUrl", "gifSize"], (data) => {
  if (data.gifUrl) document.getElementById("url").value = data.gifUrl;
  if (data.gifSize) {
    document.getElementById("size").value = data.gifSize;
    document.getElementById("sizeLabel").textContent = data.gifSize + "px";
  }
});

document.getElementById("size").addEventListener("input", (e) => {
  document.getElementById("sizeLabel").textContent = e.target.value + "px";
});

// send gif config to the active tab's content script
document.getElementById("apply").addEventListener("click", () => {
  const url = document.getElementById("url").value.trim();
  const size = parseInt(document.getElementById("size").value);
  if (!url) return;

  chrome.storage.local.set({ gifUrl: url, gifSize: size });

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: "apply", url, size });
  });
});

// tell content script to nuke the overlay
document.getElementById("remove").addEventListener("click", () => {
  chrome.storage.local.remove(["gifUrl", "gifSize", "gifPos"]);

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: "remove" });
  });
});
